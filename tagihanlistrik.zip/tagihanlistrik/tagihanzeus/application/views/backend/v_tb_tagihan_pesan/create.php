<form class="" action="<?php echo site_url ('tb_tagihan_pesan/save') ?>" method="post">
<label>Id_Pemberitahuan</label><br>
<input type="text" name="Id_Tagihan_Pesan" value=""><p></p>
<label>Id_Tagihan</label><br>
<input type="text" name="Id_Tagihan" value=""><p></p>
<label>Id_Pesan</label><br>
<input type="text" name="Id_Pesan" value=""><p></p>
<button type="submit" name="button">Simpan</button>
<a href="<?php echo site_url('tb_tagihan_pesan') ?>"><button type="button"
name="button">Batal</button></a>
</form>