<form method="post" action="<?php echo site_url('auth/login') ?>">
<label>Id Admin</label><br>
<input type="text" name="id_admin" value=""><p></p>
<label>Password</label><br>
<input type="password" name="password" value=""><p></p>
<input type="submit" value="Login">
</form>